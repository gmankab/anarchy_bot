from pathlib import Path
import sys

sys.path.append(
    str(Path(__file__).parent.resolve())
)

from anarchy_bot import main

