# changlelog

## 23.1.0

- changed response logic
- updated english translation
- fixed error when getting /help from channels

## 23.0.10

- admin panel button moved to admin help message

## 23.0.9

- "you are not allowed to touch it" renamed to "you are not bot owner"

## 23.0.8

- fixed reacting on message without space after command, now bot will not react on messages like "/help1", becouse there is no space after p
- added error message when getting /becomeadmin message from channel
- now bot owner commands will be sent only if bot owner writes /help

## 23.0.4

- fixed typos

## 23.0.3

- some fixes

## 23.0.0

- initial release

