# anarchy_bot

telegram bot that can promote any user to admin

## install

```bash
pip install -U anarchy_bot
```

## run

```bash
pythom -m anarchy_bot
```

## translete to your language

- fork repo
- go to [anarchy_bot/lang](https://github.com/gmankab/saltomaru_connect_tg/tree/main/saltomaru_connect_tg/lang)
- duplicate `en.yml` file
- rename it to something like `ru.yml`
- edit file
- make pull request
- bot automatically decects language set in user's telegram client, and will search the dir for file with translation

